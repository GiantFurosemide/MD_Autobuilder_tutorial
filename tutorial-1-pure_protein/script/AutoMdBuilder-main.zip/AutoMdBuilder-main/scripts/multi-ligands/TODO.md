* make ligand extraction a independent script for acpype
* modify mdbuild_add_one_ligand.sh  for one (kind of and one) ligand (without H) to output ligand with H and for
